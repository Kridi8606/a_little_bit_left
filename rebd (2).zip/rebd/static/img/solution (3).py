import pygame
import random


class Board:
    def __init__(self, width, height, mines):
        self.width = width
        self.height = height
        self.board = [[-1] * height for _ in range(width)]
        self.opened = [[1] * height for _ in range(width)]
        c = 0
        while c < mines:
            x, y = random.randint(0, width - 1), random.randint(0, height - 1)
            if self.board[x][y] != 10:
                self.opened[x][y] = 0
                self.board[x][y] = 10
                c += 1
        self.left = 10
        self.top = 10
        self.cell_size = 30
        self.play = True

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        for x in range(self.width):
            for y in range(self.height):
                pygame.draw.rect(screen, pygame.Color(255, 255, 255),
                                 (x * self.cell_size + self.left, y * self.cell_size + self.top,
                                  self.cell_size, self.cell_size), 1)
                if self.board[x][y] == 10:
                    pygame.draw.rect(screen, pygame.Color(255, 0, 0),
                                     (x * self.cell_size + self.left + 1, y * self.cell_size + self.top + 1,
                                      self.cell_size - 2, self.cell_size - 2))

    def get_cell(self, mouse_pos):
        x, y = (mouse_pos[0] - self.left) // self.cell_size, (mouse_pos[1] - self.top) // self.cell_size
        if 0 <= x < self.width and 0 <= y < self.height:
            return x, y

    def open_cell(self, cell_coords):
        cell = self.get_cell(cell_coords)
        if cell and self.board[cell[0]][cell[1]] == 10:
            self.game_is_over(False)
        if cell and self.board[cell[0]][cell[1]] == -1:
            neighbours = self.neighbourhood(cell)
            self.board[cell[0]][cell[1]] = neighbours
            self.opened[cell[0]][cell[1]] = 0
            font = pygame.font.Font(None, 30)
            text = font.render(str(neighbours), True, (255, 255, 255))
            text_x = cell[0] * self.cell_size + 6
            text_y = cell[1] * self.cell_size + 6
            screen.blit(text, (text_x, text_y))
            if neighbours == 0:
                for i in range(-1, 2, 1):
                    for j in range(-1, 2, 1):
                        if 0 <= cell[0] + i < self.width and 0 <= cell[1] + j < self.height and (i != 0 or j != 0) and self.opened[cell[0] + i][cell[1] + j]:
                            self.open_cell(((cell[0] + i) * self.cell_size + self.left + 1,
                                            (cell[1] + j) * self.cell_size + self.top + 1))
            pygame.display.flip()
        s = 0
        for i in self.opened:
            s += sum(i)
        if s == 0:
            self.game_is_over(True)
        return True

    def neighbourhood(self, coords):
        c = 0
        for i in range(-1, 2, 1):
            for j in range(-1, 2, 1):
                if (i != 0 or j != 0) and 0 <= coords[0] + i < width and 0 <= coords[1] + j < height and \
                        self.board[coords[0] + i][coords[1] + j] == 10:
                    c += 1
        return c

    def game_is_over(self, win):
        if not win:
            string = 'Looser'
        else:
            string = 'Winner'
        font = pygame.font.Font(None, 50)
        text = font.render(string, True, (255, 255, 255))
        text_x = width // 2 + 5
        text_y = height // 2 + 5
        text_w = text.get_width() + 5
        text_h = text.get_height() + 5
        screen.blit(text, (text_x, text_y))
        pygame.draw.rect(screen, (0, 0, 0), (text_x - 10, text_y - 10,
                                               text_w + 20, text_h + 20))
        screen.blit(text, (text_x, text_y))
        pygame.display.flip()
        return win


if __name__ == '__main__':
    pygame.init()
    cell_size = 30
    width = int(input())
    height = int(input())
    mines = int(input())
    size = width * cell_size + 10, height * cell_size + 10
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Папа сапера')
    board = Board(width, height, mines)
    board.set_view(5, 5, cell_size)
    screen.fill((0, 0, 0))
    board.render(screen)
    pygame.display.flip()
    running = True
    play = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if not play:
                    print('game is over')
                else:
                    play = board.open_cell(event.pos)
    pygame.quit()
