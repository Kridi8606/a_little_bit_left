from flask import Flask, url_for

app = Flask(__name__)


@app.route('/carousel')
def carousel():
    with open('html/main.html', 'r', encoding='utf-8') as f:
        html = f.read()
    html = html.replace('{{ style.css }}', url_for('static', filename='css/style.css'))
    for i in range(1, 6):
        html = html.replace('{{ image' + str(i) + ' }}', url_for('static', filename='img/photo' + str(i) + '.jpg'))
    return html


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')